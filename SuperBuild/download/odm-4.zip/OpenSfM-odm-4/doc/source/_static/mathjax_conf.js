MathJax.Hub.Config({
   "HTML-CSS": {
        availableFonts: ["TeX"],
        scale: 90
   }
});
