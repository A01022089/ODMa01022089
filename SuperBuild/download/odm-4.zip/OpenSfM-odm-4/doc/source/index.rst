.. OpenSfM documentation master file

OpenSfM
=======

Only tests here for now.

test contents:

.. toctree::
   :maxdepth: 2

   test
   dense


Indices and tables
==================

* :ref:`genindex`

