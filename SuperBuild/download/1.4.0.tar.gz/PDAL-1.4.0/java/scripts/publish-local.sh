#!/usr/bin/env bash

PDAL_DEPEND_ON_NATIVE=false ./sbt "project core" publish-local
