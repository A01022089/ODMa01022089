#!/usr/bin/env bash

./scripts/publish.sh
./scripts/publish-212.sh
./scripts/publish-javastyle.sh
