.. _cpp-pdal-stagefactory:

******************************************************************************
:cpp:class:`pdal::StageFactory`
******************************************************************************

.. doxygenclass:: pdal::StageFactory
   :members:
   :undoc-members:
