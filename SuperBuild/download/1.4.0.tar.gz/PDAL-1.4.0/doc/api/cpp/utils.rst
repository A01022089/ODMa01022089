.. _cpp-pdal-utils:

******************************************************************************
``pdal::Utils``
******************************************************************************

.. index:: Utils

:cpp:namespace:`pdal::Utils` is a set of utility functions.

.. doxygennamespace:: pdal::Utils
   :members:
   :undoc-members:

