.. _cpp-pdal-extractor:

******************************************************************************
:cpp:class:`pdal::Extractor`
******************************************************************************


.. doxygenclass:: pdal::Extractor
   :members:
   :undoc-members:


