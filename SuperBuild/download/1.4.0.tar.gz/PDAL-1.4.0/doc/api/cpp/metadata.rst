.. _cpp-pdal-metadata:

******************************************************************************
:cpp:class:`pdal::Metadata`
******************************************************************************


.. doxygenclass:: pdal::Metadata
   :members:
   :undoc-members:

.. doxygenclass:: pdal::MetadataNode
   :members:
   :undoc-members:

