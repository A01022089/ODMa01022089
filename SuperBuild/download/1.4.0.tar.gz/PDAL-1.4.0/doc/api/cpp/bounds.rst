.. _cpp-pdal-bounds:

******************************************************************************
:cpp:class:`pdal::BOX2D`
******************************************************************************


.. doxygenclass:: pdal::BOX2D
   :members:
   :undoc-members:

.. doxygenclass:: pdal::BOX3D
   :members:
   :undoc-members:

