.. _stage_index:

******************************************************************************
Readers, Writers, and Filters
******************************************************************************

The :cpp:class:`pdal::Stage` object encapsulates the reading, writing, and
filtering capabilities for PDAL.

:ref:`readers`, :ref:`writers`, and :ref:`filters`.
