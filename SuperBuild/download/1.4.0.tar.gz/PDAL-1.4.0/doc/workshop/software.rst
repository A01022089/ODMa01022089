.. _software:

Software Installation
====================================================

.. include:: ./includes/substitutions.rst

.. toctree::
   :maxdepth: 2

   docker
   qgis




