PDAL
====

[![Join the chat at https://gitter.im/PDAL/PDAL](https://badges.gitter.im/PDAL/PDAL.svg)](https://gitter.im/PDAL/PDAL?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

[![Build Status](https://travis-ci.org/PDAL/PDAL.png?branch=master)](https://travis-ci.org/PDAL/PDAL)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/6dehrm0v22cw58d3/branch/master?svg=true)](https://ci.appveyor.com/project/hobu/pdal)

See http://www.pdal.io/ for more info
