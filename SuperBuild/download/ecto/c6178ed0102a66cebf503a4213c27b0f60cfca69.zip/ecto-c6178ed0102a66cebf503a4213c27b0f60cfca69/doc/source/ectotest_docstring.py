#!/usr/bin/python

import ecto.ecto_test as ecto_test
print help(ecto_test.Add)

