#!/usr/bin/env python
# this file is almost the same as the hello.py : it is meant to be used from the docs
import ecto.tutorial as tutorial

printer = tutorial.Hello()
printer.process()
