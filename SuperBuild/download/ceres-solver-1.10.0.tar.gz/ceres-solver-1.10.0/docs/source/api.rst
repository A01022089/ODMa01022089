.. _chapter-api:

=============
API Reference
=============

.. toctree::
   :maxdepth: 3

   nnls_modeling
   nnls_solving
   gradient_solver
