User Guide
==========

.. toctree::
   :maxdepth: 2

   installation
   find_package
   setup_dot_py
   standards
   variables
   environment
   glossary
