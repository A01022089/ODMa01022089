import std_msgs.msg

s = std_msgs.msg.String()

print "<<< a >>>"
print type(s)


