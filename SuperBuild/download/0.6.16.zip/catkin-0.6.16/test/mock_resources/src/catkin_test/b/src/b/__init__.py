import std_msgs.msg
import a.msg
import b.msg
s = std_msgs.msg.String()
a = a.msg.AMsg()
b = b.msg.BMsg()

print "<<< b >>>"


