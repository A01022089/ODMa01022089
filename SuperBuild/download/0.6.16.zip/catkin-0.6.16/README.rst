catkin
======

Catkin is a collection of cmake macros and associated python code used
to build some parts of `ROS <http://www.ros.org>`_

Documentation
-------------

http://ros.org/doc/api/catkin/html/
